<!DOCTYPE html>
<html lang="en-US">
<head>
	<meta charset="UTF-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<link rel="profile" href="http://gmpg.org/xfn/11" />
	<link rel="pingback" href="https://kaabworldwidetarot.shop/xmlrpc.php" />
	<meta name='robots' content='noindex, follow' />
	<style>img:is([sizes="auto" i], [sizes^="auto," i]) { contain-intrinsic-size: 3000px 1500px }</style>
	
	<!-- This site is optimized with the Yoast SEO plugin v26.0 - https://yoast.com/wordpress/plugins/seo/ -->
	<title>Page not found - kaabworldwidemarkating.online</title>
	<meta property="og:locale" content="en_US" />
	<meta property="og:title" content="Page not found - kaabworldwidemarkating.online" />
	<meta property="og:site_name" content="kaabworldwidemarkating.online" />
	<script type="application/ld+json" class="yoast-schema-graph">{"@context":"https://schema.org","@graph":[{"@type":"WebSite","@id":"https://kaabworldwidetarot.shop/#website","url":"https://kaabworldwidetarot.shop/","name":"kaabworldwidemarkating.online","description":"","potentialAction":[{"@type":"SearchAction","target":{"@type":"EntryPoint","urlTemplate":"https://kaabworldwidetarot.shop/?s={search_term_string}"},"query-input":{"@type":"PropertyValueSpecification","valueRequired":true,"valueName":"search_term_string"}}],"inLanguage":"en-US"}]}</script>
	<!-- / Yoast SEO plugin. -->


<link rel="alternate" type="application/rss+xml" title="kaabworldwidemarkating.online &raquo; Feed" href="https://kaabworldwidetarot.shop/feed/" />
<link rel="alternate" type="application/rss+xml" title="kaabworldwidemarkating.online &raquo; Comments Feed" href="https://kaabworldwidetarot.shop/comments/feed/" />
<script>
window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/16.0.1\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/16.0.1\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/kaabworldwidetarot.shop\/wp-includes\/js\/wp-emoji-release.min.js?ver=6.8.3"}};
/*! This file is auto-generated */
!function(s,n){var o,i,e;function c(e){try{var t={supportTests:e,timestamp:(new Date).valueOf()};sessionStorage.setItem(o,JSON.stringify(t))}catch(e){}}function p(e,t,n){e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(t,0,0);var t=new Uint32Array(e.getImageData(0,0,e.canvas.width,e.canvas.height).data),a=(e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(n,0,0),new Uint32Array(e.getImageData(0,0,e.canvas.width,e.canvas.height).data));return t.every(function(e,t){return e===a[t]})}function u(e,t){e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(t,0,0);for(var n=e.getImageData(16,16,1,1),a=0;a<n.data.length;a++)if(0!==n.data[a])return!1;return!0}function f(e,t,n,a){switch(t){case"flag":return n(e,"\ud83c\udff3\ufe0f\u200d\u26a7\ufe0f","\ud83c\udff3\ufe0f\u200b\u26a7\ufe0f")?!1:!n(e,"\ud83c\udde8\ud83c\uddf6","\ud83c\udde8\u200b\ud83c\uddf6")&&!n(e,"\ud83c\udff4\udb40\udc67\udb40\udc62\udb40\udc65\udb40\udc6e\udb40\udc67\udb40\udc7f","\ud83c\udff4\u200b\udb40\udc67\u200b\udb40\udc62\u200b\udb40\udc65\u200b\udb40\udc6e\u200b\udb40\udc67\u200b\udb40\udc7f");case"emoji":return!a(e,"\ud83e\udedf")}return!1}function g(e,t,n,a){var r="undefined"!=typeof WorkerGlobalScope&&self instanceof WorkerGlobalScope?new OffscreenCanvas(300,150):s.createElement("canvas"),o=r.getContext("2d",{willReadFrequently:!0}),i=(o.textBaseline="top",o.font="600 32px Arial",{});return e.forEach(function(e){i[e]=t(o,e,n,a)}),i}function t(e){var t=s.createElement("script");t.src=e,t.defer=!0,s.head.appendChild(t)}"undefined"!=typeof Promise&&(o="wpEmojiSettingsSupports",i=["flag","emoji"],n.supports={everything:!0,everythingExceptFlag:!0},e=new Promise(function(e){s.addEventListener("DOMContentLoaded",e,{once:!0})}),new Promise(function(t){var n=function(){try{var e=JSON.parse(sessionStorage.getItem(o));if("object"==typeof e&&"number"==typeof e.timestamp&&(new Date).valueOf()<e.timestamp+604800&&"object"==typeof e.supportTests)return e.supportTests}catch(e){}return null}();if(!n){if("undefined"!=typeof Worker&&"undefined"!=typeof OffscreenCanvas&&"undefined"!=typeof URL&&URL.createObjectURL&&"undefined"!=typeof Blob)try{var e="postMessage("+g.toString()+"("+[JSON.stringify(i),f.toString(),p.toString(),u.toString()].join(",")+"));",a=new Blob([e],{type:"text/javascript"}),r=new Worker(URL.createObjectURL(a),{name:"wpTestEmojiSupports"});return void(r.onmessage=function(e){c(n=e.data),r.terminate(),t(n)})}catch(e){}c(n=g(i,f,p,u))}t(n)}).then(function(e){for(var t in e)n.supports[t]=e[t],n.supports.everything=n.supports.everything&&n.supports[t],"flag"!==t&&(n.supports.everythingExceptFlag=n.supports.everythingExceptFlag&&n.supports[t]);n.supports.everythingExceptFlag=n.supports.everythingExceptFlag&&!n.supports.flag,n.DOMReady=!1,n.readyCallback=function(){n.DOMReady=!0}}).then(function(){return e}).then(function(){var e;n.supports.everything||(n.readyCallback(),(e=n.source||{}).concatemoji?t(e.concatemoji):e.wpemoji&&e.twemoji&&(t(e.twemoji),t(e.wpemoji)))}))}((window,document),window._wpemojiSettings);
</script>
<link rel='stylesheet' id='hfe-widgets-style-css' href='https://kaabworldwidetarot.shop/wp-content/plugins/header-footer-elementor/inc/widgets-css/frontend.css?ver=2.5.2' media='all' />
<style id='wp-emoji-styles-inline-css'>

	img.wp-smiley, img.emoji {
		display: inline !important;
		border: none !important;
		box-shadow: none !important;
		height: 1em !important;
		width: 1em !important;
		margin: 0 0.07em !important;
		vertical-align: -0.1em !important;
		background: none !important;
		padding: 0 !important;
	}
</style>
<style id='wp-block-library-inline-css'>
:root{--wp-admin-theme-color:#007cba;--wp-admin-theme-color--rgb:0,124,186;--wp-admin-theme-color-darker-10:#006ba1;--wp-admin-theme-color-darker-10--rgb:0,107,161;--wp-admin-theme-color-darker-20:#005a87;--wp-admin-theme-color-darker-20--rgb:0,90,135;--wp-admin-border-width-focus:2px;--wp-block-synced-color:#7a00df;--wp-block-synced-color--rgb:122,0,223;--wp-bound-block-color:var(--wp-block-synced-color)}@media (min-resolution:192dpi){:root{--wp-admin-border-width-focus:1.5px}}.wp-element-button{cursor:pointer}:root{--wp--preset--font-size--normal:16px;--wp--preset--font-size--huge:42px}:root .has-very-light-gray-background-color{background-color:#eee}:root .has-very-dark-gray-background-color{background-color:#313131}:root .has-very-light-gray-color{color:#eee}:root .has-very-dark-gray-color{color:#313131}:root .has-vivid-green-cyan-to-vivid-cyan-blue-gradient-background{background:linear-gradient(135deg,#00d084,#0693e3)}:root .has-purple-crush-gradient-background{background:linear-gradient(135deg,#34e2e4,#4721fb 50%,#ab1dfe)}:root .has-hazy-dawn-gradient-background{background:linear-gradient(135deg,#faaca8,#dad0ec)}:root .has-subdued-olive-gradient-background{background:linear-gradient(135deg,#fafae1,#67a671)}:root .has-atomic-cream-gradient-background{background:linear-gradient(135deg,#fdd79a,#004a59)}:root .has-nightshade-gradient-background{background:linear-gradient(135deg,#330968,#31cdcf)}:root .has-midnight-gradient-background{background:linear-gradient(135deg,#020381,#2874fc)}.has-regular-font-size{font-size:1em}.has-larger-font-size{font-size:2.625em}.has-normal-font-size{font-size:var(--wp--preset--font-size--normal)}.has-huge-font-size{font-size:var(--wp--preset--font-size--huge)}.has-text-align-center{text-align:center}.has-text-align-left{text-align:left}.has-text-align-right{text-align:right}#end-resizable-editor-section{display:none}.aligncenter{clear:both}.items-justified-left{justify-content:flex-start}.items-justified-center{justify-content:center}.items-justified-right{justify-content:flex-end}.items-justified-space-between{justify-content:space-between}.screen-reader-text{border:0;clip-path:inset(50%);height:1px;margin:-1px;overflow:hidden;padding:0;position:absolute;width:1px;word-wrap:normal!important}.screen-reader-text:focus{background-color:#ddd;clip-path:none;color:#444;display:block;font-size:1em;height:auto;left:5px;line-height:normal;padding:15px 23px 14px;text-decoration:none;top:5px;width:auto;z-index:100000}html :where(.has-border-color){border-style:solid}html :where([style*=border-top-color]){border-top-style:solid}html :where([style*=border-right-color]){border-right-style:solid}html :where([style*=border-bottom-color]){border-bottom-style:solid}html :where([style*=border-left-color]){border-left-style:solid}html :where([style*=border-width]){border-style:solid}html :where([style*=border-top-width]){border-top-style:solid}html :where([style*=border-right-width]){border-right-style:solid}html :where([style*=border-bottom-width]){border-bottom-style:solid}html :where([style*=border-left-width]){border-left-style:solid}html :where(img[class*=wp-image-]){height:auto;max-width:100%}:where(figure){margin:0 0 1em}html :where(.is-position-sticky){--wp-admin--admin-bar--position-offset:var(--wp-admin--admin-bar--height,0px)}@media screen and (max-width:600px){html :where(.is-position-sticky){--wp-admin--admin-bar--position-offset:0px}}
</style>
<link rel='stylesheet' id='gutenkit-frontend-common-css' href='https://kaabworldwidetarot.shop/wp-content/plugins/gutenkit-blocks-addon/build/gutenkit/frontend-common.css?ver=a28538744097629e283d' media='all' />
<link rel='stylesheet' id='popup-builder-block-global-css' href='https://kaabworldwidetarot.shop/wp-content/plugins/popup-builder-block/build/popup/global.css?ver=2.2.3' media='all' />
<link rel='stylesheet' id='contact-form-7-css' href='https://kaabworldwidetarot.shop/wp-content/plugins/contact-form-7/includes/css/styles.css?ver=6.1.4' media='all' />
<link rel='stylesheet' id='xs-front-style-css' href='https://kaabworldwidetarot.shop/wp-content/plugins/wp-social/assets/css/frontend.css?ver=3.1.4' media='all' />
<link rel='stylesheet' id='xs_login_font_login_css-css' href='https://kaabworldwidetarot.shop/wp-content/plugins/wp-social/assets/css/font-icon.css?ver=3.1.4' media='all' />
<link rel='stylesheet' id='hfe-style-css' href='https://kaabworldwidetarot.shop/wp-content/plugins/header-footer-elementor/assets/css/header-footer-elementor.css?ver=2.5.2' media='all' />
<link rel='stylesheet' id='elementor-frontend-css' href='https://kaabworldwidetarot.shop/wp-content/plugins/elementor/assets/css/frontend.min.css?ver=3.33.4' media='all' />
<link rel='stylesheet' id='elementor-post-8-css' href='https://kaabworldwidetarot.shop/wp-content/uploads/elementor/css/post-8.css?ver=1770162678' media='all' />
<link rel='stylesheet' id='elementor-post-40-css' href='https://kaabworldwidetarot.shop/wp-content/uploads/elementor/css/post-40.css?ver=1770162679' media='all' />
<link rel='stylesheet' id='elementor-post-48-css' href='https://kaabworldwidetarot.shop/wp-content/uploads/elementor/css/post-48.css?ver=1770162679' media='all' />
<link rel='stylesheet' id='gutenkit-third-party-editor-compatibility-css' href='https://kaabworldwidetarot.shop/wp-content/plugins/popup-builder-block/build/compatibility/frontend.css?ver=3d448a7df93bfa355643' media='all' />
<link rel='stylesheet' id='qi-addons-for-elementor-grid-style-css' href='https://kaabworldwidetarot.shop/wp-content/plugins/qi-addons-for-elementor/assets/css/grid.min.css?ver=1.9.3' media='all' />
<link rel='stylesheet' id='qi-addons-for-elementor-helper-parts-style-css' href='https://kaabworldwidetarot.shop/wp-content/plugins/qi-addons-for-elementor/assets/css/helper-parts.min.css?ver=1.9.3' media='all' />
<link rel='stylesheet' id='qi-addons-for-elementor-style-css' href='https://kaabworldwidetarot.shop/wp-content/plugins/qi-addons-for-elementor/assets/css/main.min.css?ver=1.9.3' media='all' />
<link rel='stylesheet' id='cute-alert-css' href='https://kaabworldwidetarot.shop/wp-content/plugins/metform/public/assets/lib/cute-alert/style.css?ver=4.0.5' media='all' />
<link rel='stylesheet' id='text-editor-style-css' href='https://kaabworldwidetarot.shop/wp-content/plugins/metform/public/assets/css/text-editor.css?ver=4.0.5' media='all' />
<link rel='stylesheet' id='wur_content_css-css' href='https://kaabworldwidetarot.shop/wp-content/plugins/wp-ultimate-review/assets/public/css/content-page.css?ver=2.3.7' media='all' />
<link rel='stylesheet' id='dashicons-css' href='https://kaabworldwidetarot.shop/wp-includes/css/dashicons.min.css?ver=6.8.3' media='all' />
<link rel='stylesheet' id='hello-elementor-css' href='https://kaabworldwidetarot.shop/wp-content/themes/hello-elementor/assets/css/reset.css?ver=3.4.4' media='all' />
<link rel='stylesheet' id='hello-elementor-theme-style-css' href='https://kaabworldwidetarot.shop/wp-content/themes/hello-elementor/assets/css/theme.css?ver=3.4.4' media='all' />
<link rel='stylesheet' id='hello-elementor-header-footer-css' href='https://kaabworldwidetarot.shop/wp-content/themes/hello-elementor/assets/css/header-footer.css?ver=3.4.4' media='all' />
<link rel='stylesheet' id='swiper-css' href='https://kaabworldwidetarot.shop/wp-content/plugins/qi-addons-for-elementor/assets/plugins/swiper/8.4.5/swiper.min.css?ver=8.4.5' media='all' />
<link rel='stylesheet' id='hfe-elementor-icons-css' href='https://kaabworldwidetarot.shop/wp-content/plugins/elementor/assets/lib/eicons/css/elementor-icons.min.css?ver=5.34.0' media='all' />
<link rel='stylesheet' id='hfe-icons-list-css' href='https://kaabworldwidetarot.shop/wp-content/plugins/elementor/assets/css/widget-icon-list.min.css?ver=3.24.3' media='all' />
<link rel='stylesheet' id='hfe-social-icons-css' href='https://kaabworldwidetarot.shop/wp-content/plugins/elementor/assets/css/widget-social-icons.min.css?ver=3.24.0' media='all' />
<link rel='stylesheet' id='hfe-social-share-icons-brands-css' href='https://kaabworldwidetarot.shop/wp-content/plugins/elementor/assets/lib/font-awesome/css/brands.css?ver=5.15.3' media='all' />
<link rel='stylesheet' id='hfe-social-share-icons-fontawesome-css' href='https://kaabworldwidetarot.shop/wp-content/plugins/elementor/assets/lib/font-awesome/css/fontawesome.css?ver=5.15.3' media='all' />
<link rel='stylesheet' id='hfe-nav-menu-icons-css' href='https://kaabworldwidetarot.shop/wp-content/plugins/elementor/assets/lib/font-awesome/css/solid.css?ver=5.15.3' media='all' />
<link rel='stylesheet' id='ekit-widget-styles-css' href='https://kaabworldwidetarot.shop/wp-content/plugins/elementskit-lite/widgets/init/assets/css/widget-styles.css?ver=3.6.1' media='all' />
<link rel='stylesheet' id='ekit-responsive-css' href='https://kaabworldwidetarot.shop/wp-content/plugins/elementskit-lite/widgets/init/assets/css/responsive.css?ver=3.6.1' media='all' />
<link rel='stylesheet' id='elementor-gf-local-roboto-css' href='http://kaabworldwidetarot.shop/wp-content/uploads/elementor/google-fonts/css/roboto.css?ver=1756123778' media='all' />
<link rel='stylesheet' id='elementor-gf-local-robotoslab-css' href='http://kaabworldwidetarot.shop/wp-content/uploads/elementor/google-fonts/css/robotoslab.css?ver=1756123883' media='all' />
<link rel='stylesheet' id='elementor-gf-local-plusjakartasans-css' href='http://kaabworldwidetarot.shop/wp-content/uploads/elementor/google-fonts/css/plusjakartasans.css?ver=1756123884' media='all' />
<link rel='stylesheet' id='elementor-gf-local-playfairdisplay-css' href='http://kaabworldwidetarot.shop/wp-content/uploads/elementor/google-fonts/css/playfairdisplay.css?ver=1756124099' media='all' />
<link rel='stylesheet' id='elementor-icons-ekiticons-css' href='https://kaabworldwidetarot.shop/wp-content/plugins/elementskit-lite/modules/elementskit-icon-pack/assets/css/ekiticons.css?ver=3.6.1' media='all' />
<script src="https://kaabworldwidetarot.shop/wp-includes/js/jquery/jquery.min.js?ver=3.7.1" id="jquery-core-js"></script>
<script src="https://kaabworldwidetarot.shop/wp-includes/js/jquery/jquery-migrate.min.js?ver=3.4.1" id="jquery-migrate-js"></script>
<script id="jquery-js-after">
!function($){"use strict";$(document).ready(function(){$(this).scrollTop()>100&&$(".hfe-scroll-to-top-wrap").removeClass("hfe-scroll-to-top-hide"),$(window).scroll(function(){$(this).scrollTop()<100?$(".hfe-scroll-to-top-wrap").fadeOut(300):$(".hfe-scroll-to-top-wrap").fadeIn(300)}),$(".hfe-scroll-to-top-wrap").on("click",function(){$("html, body").animate({scrollTop:0},300);return!1})})}(jQuery);
!function($){'use strict';$(document).ready(function(){var bar=$('.hfe-reading-progress-bar');if(!bar.length)return;$(window).on('scroll',function(){var s=$(window).scrollTop(),d=$(document).height()-$(window).height(),p=d? s/d*100:0;bar.css('width',p+'%')});});}(jQuery);
</script>
<script id="xs_front_main_js-js-extra">
var rest_config = {"rest_url":"https:\/\/kaabworldwidetarot.shop\/wp-json\/","nonce":"5ffec83539","insta_enabled":""};
</script>
<script src="https://kaabworldwidetarot.shop/wp-content/plugins/wp-social/assets/js/front-main.js?ver=3.1.4" id="xs_front_main_js-js"></script>
<script id="xs_social_custom-js-extra">
var rest_api_conf = {"siteurl":"http:\/\/kaabworldwidetarot.shop","nonce":"5ffec83539","root":"https:\/\/kaabworldwidetarot.shop\/wp-json\/"};
var wsluFrontObj = {"resturl":"https:\/\/kaabworldwidetarot.shop\/wp-json\/","rest_nonce":"5ffec83539"};
</script>
<script src="https://kaabworldwidetarot.shop/wp-content/plugins/wp-social/assets/js/social-front.js?ver=3.1.4" id="xs_social_custom-js"></script>
<script src="https://kaabworldwidetarot.shop/wp-content/plugins/wp-ultimate-review/assets/public/script/content-page.js?ver=2.3.7" id="wur_review_content_script-js"></script>
<link rel="https://api.w.org/" href="https://kaabworldwidetarot.shop/wp-json/" /><link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://kaabworldwidetarot.shop/xmlrpc.php?rsd" />
<meta name="generator" content="WordPress 6.8.3" />
<script type='text/javascript'>var breakpoints = [{"label":"Desktop","slug":"Desktop","value":"base","direction":"max","isActive":true,"isRequired":true},{"label":"Tablet","slug":"Tablet","value":"1024","direction":"max","isActive":true,"isRequired":true},{"label":"Mobile","slug":"Mobile","value":"767","direction":"max","isActive":true,"isRequired":true}];</script><meta name="google-site-verification" content="c4zsIQbriUm8ImQ3vg8rrDkzHWprC8xd1ZVyWZC-AyY" /><meta name="generator" content="Elementor 3.33.4; features: e_font_icon_svg, additional_custom_breakpoints; settings: css_print_method-external, google_font-enabled, font_display-swap">
			<style>
				.e-con.e-parent:nth-of-type(n+4):not(.e-lazyloaded):not(.e-no-lazyload),
				.e-con.e-parent:nth-of-type(n+4):not(.e-lazyloaded):not(.e-no-lazyload) * {
					background-image: none !important;
				}
				@media screen and (max-height: 1024px) {
					.e-con.e-parent:nth-of-type(n+3):not(.e-lazyloaded):not(.e-no-lazyload),
					.e-con.e-parent:nth-of-type(n+3):not(.e-lazyloaded):not(.e-no-lazyload) * {
						background-image: none !important;
					}
				}
				@media screen and (max-height: 640px) {
					.e-con.e-parent:nth-of-type(n+2):not(.e-lazyloaded):not(.e-no-lazyload),
					.e-con.e-parent:nth-of-type(n+2):not(.e-lazyloaded):not(.e-no-lazyload) * {
						background-image: none !important;
					}
				}
			</style>
					<style id="wp-custom-css">
			/* === Dark Mode Blog Page Fix === */

/* Overall Layout */
body.single-post {
  background: #000 !important;
  color: #fff !important;
}

/* Blog Title */
.single-post h1.entry-title {
  font-size: 42px !important;
  line-height: 1.3 !important;
  color: #ffffff !important;
  text-align: center !important;
  margin-top: 100px !important;
  margin-bottom: 40px !important;
  font-weight: 700 !important;
}

/* Blog Content Container */
.single-post .site-content,
.single-post .entry-content,
.single-post article {
  background: #000 !important;
  padding: 40px 50px !important;
  color: #f5f5f5 !important;
}

/* Paragraph Styling */
.single-post .entry-content p {
  margin-bottom: 20px !important;
  line-height: 1.8 !important;
  font-size: 17px !important;
  color: #f5f5f5 !important;
}

/* Headings inside content */
.single-post .entry-content h2,
.single-post .entry-content h3 {
  color: #ffffff !important;
  margin-top: 35px !important;
  margin-bottom: 15px !important;
  font-weight: 600 !important;
}

/* Bullet & Number Lists */
.single-post .entry-content ul,
.single-post .entry-content ol {
  margin: 15px 0 25px 25px !important;
  line-height: 1.8 !important;
  color: #f5f5f5 !important;
}

/* Image Formatting */
.single-post .entry-content img {
  display: block !important;
  margin: 30px auto !important;
  border-radius: 10px !important;
  max-width: 100% !important;
}

/* Navbar Text Overlap Fix */
header, .site-header, .main-header {
  z-index: 99 !important;
  position: relative !important;
}

.single-post h1.entry-title {
  margin-top: 120px !important;
}


.callMePanel {
    position: fixed;
    top: 35%;
    right: -275px; /* hidden */
    width: 275px;
    z-index: 999999;
    transition: all 0.3s ease;
}

.callMePanel.active {
    right: 0; /* show */
}

.iconMobPanel {
    position: absolute;
    left: -36px;
    top: 0;
    background: #ff971c;
    padding: 8px 10px;
    border-radius: 7px 0 0 7px;
    cursor: pointer;
}

.iconMobPanel img {
    width: 100%;
}

.callMePanelBottom {
    background: #ececec;
    padding: 20px;
    border: 1px solid #cac7c7;
    border-right: 0;
}
.callMePanelBottom .formHead {
    font-size: 18px;
    line-height: 26px;
    margin-bottom: 10px;
    color: #000;
    font-weight: 600;
}
.callMePanelBottom input[type=email], .callMePanelBottom input[type=tel], .callMePanelBottom input[type=text], .callMePanelBottom textarea{
	 border: 1px solid #bdbdbd;
    border-radius: 7px;
    margin-bottom: 5px!important;
    color: #565656 !important;
    font-size: 12px;
    padding: 4px 5px;
    vertical-align: middle;
    width: 100% !important;
    height: auto !important;
}
.callMePanelBottom textarea{
	height:60px !important;
}
.callMePanelBottom input.wpcf7-submit{
    padding: 10px 20px;
    border: none;
    margin-top: 10px;
}

/* Wrapper */
.nf-sticky-wrapper {
            position: fixed;
            left: 0;
            bottom: 30%;
            z-index: 9999;
            font-family: Arial, sans-serif;
        }

        .nf-arrow-btn {
            background: #000;
            color: #fff;
            padding: 12px;
            cursor: pointer;
            text-align: center;
            font-size: 18px;
        }

        .nf-social-list {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        /* DEFAULT SHOW */
        .nf-social-item {
            display: block;
        }

        .nf-social-item a {
            display: block;
            padding: 12px 15px;
            color: #fff;
            text-decoration: none;
        }

        .whatsapp { background: #26D367; }
        .facebook { background: #4267B2; }
        .instagram { background: #E1306C; }
        .youtube { background: #F54E4E; }
        .map { background: #3AAB58; }



/* Mobile Optimization */
@media (max-width: 768px) {
  .single-post h1.entry-title {
    font-size: 28px !important;
    margin-top: 90px !important;
  }

  .single-post .entry-content {
    padding: 25px !important;
  }
	 .nf-sticky-wrapper {
        position: fixed;
        bottom: 0;
        left: 0;
        top: auto;
        transform: none;
        width: 100%;
        z-index: 9999;
    }

    .nf-social-list {
        display: flex;
        justify-content: space-between;
    }

    .nf-social-item {
        width: 20%;
			padding-left: 10PX !important;
    }

    .nf-social-item a {
        justify-content: center;
        padding: 10px 0;
        font-size: 12px;
    }

    /* hover expand mobile me off */
    .nf-social-item:hover {
        width: 20%;
    }
}
		</style>
		</head>

<body class="error404 wp-embed-responsive wp-theme-hello-elementor gutenkit gutenkit-frontend ehf-header ehf-footer ehf-template-hello-elementor ehf-stylesheet-hello-elementor qodef-qi--no-touch qi-addons-for-elementor-1.9.3 hello-elementor-default elementor-default elementor-kit-8">
<div id="page" class="hfeed site">

		<header id="masthead" itemscope="itemscope" itemtype="https://schema.org/WPHeader">
			<p class="main-title bhf-hidden" itemprop="headline"><a href="https://kaabworldwidetarot.shop" title="kaabworldwidemarkating.online" rel="home">kaabworldwidemarkating.online</a></p>
					<div data-elementor-type="wp-post" data-elementor-id="40" class="elementor elementor-40">
				<div class="elementor-element elementor-element-61ab0515 e-flex e-con-boxed e-con e-parent" data-id="61ab0515" data-element_type="container">
					<div class="e-con-inner">
		<div class="elementor-element elementor-element-52a94da e-con-full e-flex e-con e-child" data-id="52a94da" data-element_type="container">
		<div class="elementor-element elementor-element-5b221d3b e-con-full e-flex e-con e-child" data-id="5b221d3b" data-element_type="container">
				<div class="elementor-element elementor-element-964c08c elementor-widget elementor-widget-image" data-id="964c08c" data-element_type="widget" data-widget_type="image.default">
															<img width="250" height="122" src="https://kaabworldwidetarot.shop/wp-content/uploads/2025/08/ngs-1.webp" class="attachment-large size-large wp-image-1790" alt="" />															</div>
				</div>
		<div class="elementor-element elementor-element-4d039afe e-con-full e-flex e-con e-child" data-id="4d039afe" data-element_type="container">
		<div class="elementor-element elementor-element-196384b8 e-con-full e-flex e-con e-child" data-id="196384b8" data-element_type="container">
				<div class="elementor-element elementor-element-68d09f0a hfe-nav-menu__align-right hfe-submenu-icon-arrow hfe-submenu-animation-none hfe-link-redirect-child hfe-nav-menu__breakpoint-tablet elementor-widget elementor-widget-navigation-menu" data-id="68d09f0a" data-element_type="widget" data-settings="{&quot;menu_space_between&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:50,&quot;sizes&quot;:[]},&quot;dropdown_border_radius&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;top&quot;:&quot;25&quot;,&quot;right&quot;:&quot;25&quot;,&quot;bottom&quot;:&quot;25&quot;,&quot;left&quot;:&quot;25&quot;,&quot;isLinked&quot;:true},&quot;padding_horizontal_menu_item&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:0,&quot;sizes&quot;:[]},&quot;padding_horizontal_menu_item_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:30,&quot;sizes&quot;:[]},&quot;padding_horizontal_menu_item_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;padding_vertical_menu_item&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:15,&quot;sizes&quot;:[]},&quot;padding_vertical_menu_item_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;padding_vertical_menu_item_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;menu_space_between_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;menu_space_between_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;menu_row_space&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;menu_row_space_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;menu_row_space_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;dropdown_border_radius_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;top&quot;:&quot;&quot;,&quot;right&quot;:&quot;&quot;,&quot;bottom&quot;:&quot;&quot;,&quot;left&quot;:&quot;&quot;,&quot;isLinked&quot;:true},&quot;dropdown_border_radius_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;top&quot;:&quot;&quot;,&quot;right&quot;:&quot;&quot;,&quot;bottom&quot;:&quot;&quot;,&quot;left&quot;:&quot;&quot;,&quot;isLinked&quot;:true},&quot;width_dropdown_item&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;220&quot;,&quot;sizes&quot;:[]},&quot;width_dropdown_item_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;width_dropdown_item_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;padding_horizontal_dropdown_item&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;padding_horizontal_dropdown_item_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;padding_horizontal_dropdown_item_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;padding_vertical_dropdown_item&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:15,&quot;sizes&quot;:[]},&quot;padding_vertical_dropdown_item_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;padding_vertical_dropdown_item_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;distance_from_menu&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;distance_from_menu_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;distance_from_menu_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;toggle_size&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;toggle_size_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;toggle_size_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;toggle_border_width&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;toggle_border_width_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;toggle_border_width_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;toggle_border_radius&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;toggle_border_radius_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;toggle_border_radius_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]}}" data-widget_type="navigation-menu.default">
				<div class="elementor-widget-container">
								<div class="hfe-nav-menu hfe-layout-horizontal hfe-nav-menu-layout horizontal hfe-pointer__none" data-layout="horizontal">
				<div role="button" class="hfe-nav-menu__toggle elementor-clickable" tabindex="0" aria-label="Menu Toggle">
					<span class="screen-reader-text">Menu</span>
					<div class="hfe-nav-menu-icon">
						<svg aria-hidden="true"  class="e-font-icon-svg e-fas-align-justify" viewBox="0 0 448 512" xmlns="http://www.w3.org/2000/svg"><path d="M432 416H16a16 16 0 0 0-16 16v32a16 16 0 0 0 16 16h416a16 16 0 0 0 16-16v-32a16 16 0 0 0-16-16zm0-128H16a16 16 0 0 0-16 16v32a16 16 0 0 0 16 16h416a16 16 0 0 0 16-16v-32a16 16 0 0 0-16-16zm0-128H16a16 16 0 0 0-16 16v32a16 16 0 0 0 16 16h416a16 16 0 0 0 16-16v-32a16 16 0 0 0-16-16zm0-128H16A16 16 0 0 0 0 48v32a16 16 0 0 0 16 16h416a16 16 0 0 0 16-16V48a16 16 0 0 0-16-16z"></path></svg>					</div>
				</div>
				<nav class="hfe-nav-menu__layout-horizontal hfe-nav-menu__submenu-arrow" data-toggle-icon="&lt;svg aria-hidden=&quot;true&quot; tabindex=&quot;0&quot; class=&quot;e-font-icon-svg e-fas-align-justify&quot; viewBox=&quot;0 0 448 512&quot; xmlns=&quot;http://www.w3.org/2000/svg&quot;&gt;&lt;path d=&quot;M432 416H16a16 16 0 0 0-16 16v32a16 16 0 0 0 16 16h416a16 16 0 0 0 16-16v-32a16 16 0 0 0-16-16zm0-128H16a16 16 0 0 0-16 16v32a16 16 0 0 0 16 16h416a16 16 0 0 0 16-16v-32a16 16 0 0 0-16-16zm0-128H16a16 16 0 0 0-16 16v32a16 16 0 0 0 16 16h416a16 16 0 0 0 16-16v-32a16 16 0 0 0-16-16zm0-128H16A16 16 0 0 0 0 48v32a16 16 0 0 0 16 16h416a16 16 0 0 0 16-16V48a16 16 0 0 0-16-16z&quot;&gt;&lt;/path&gt;&lt;/svg&gt;" data-close-icon="&lt;svg aria-hidden=&quot;true&quot; tabindex=&quot;0&quot; class=&quot;e-font-icon-svg e-far-window-close&quot; viewBox=&quot;0 0 512 512&quot; xmlns=&quot;http://www.w3.org/2000/svg&quot;&gt;&lt;path d=&quot;M464 32H48C21.5 32 0 53.5 0 80v352c0 26.5 21.5 48 48 48h416c26.5 0 48-21.5 48-48V80c0-26.5-21.5-48-48-48zm0 394c0 3.3-2.7 6-6 6H54c-3.3 0-6-2.7-6-6V86c0-3.3 2.7-6 6-6h404c3.3 0 6 2.7 6 6v340zM356.5 194.6L295.1 256l61.4 61.4c4.6 4.6 4.6 12.1 0 16.8l-22.3 22.3c-4.6 4.6-12.1 4.6-16.8 0L256 295.1l-61.4 61.4c-4.6 4.6-12.1 4.6-16.8 0l-22.3-22.3c-4.6-4.6-4.6-12.1 0-16.8l61.4-61.4-61.4-61.4c-4.6-4.6-4.6-12.1 0-16.8l22.3-22.3c4.6-4.6 12.1-4.6 16.8 0l61.4 61.4 61.4-61.4c4.6-4.6 12.1-4.6 16.8 0l22.3 22.3c4.7 4.6 4.7 12.1 0 16.8z&quot;&gt;&lt;/path&gt;&lt;/svg&gt;" data-full-width="yes">
					<ul id="menu-1-68d09f0a" class="hfe-nav-menu"><li id="menu-item-103" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home parent hfe-creative-menu"><a href="https://kaabworldwidetarot.shop/" class = "hfe-menu-item">Home</a></li>
<li id="menu-item-105" class="menu-item menu-item-type-post_type menu-item-object-page parent hfe-creative-menu"><a href="https://kaabworldwidetarot.shop/about-us/" class = "hfe-menu-item">About us</a></li>
<li id="menu-item-1005" class="menu-item menu-item-type-post_type menu-item-object-page parent hfe-creative-menu"><a href="https://kaabworldwidetarot.shop/our-team/" class = "hfe-menu-item">Our Team</a></li>
<li id="menu-item-107" class="menu-item menu-item-type-post_type menu-item-object-page parent hfe-creative-menu"><a href="https://kaabworldwidetarot.shop/service/" class = "hfe-menu-item">Services</a></li>
<li id="menu-item-612" class="menu-item menu-item-type-post_type menu-item-object-page parent hfe-creative-menu"><a href="https://kaabworldwidetarot.shop/blog/" class = "hfe-menu-item">Blog</a></li>
<li id="menu-item-106" class="menu-item menu-item-type-post_type menu-item-object-page parent hfe-creative-menu"><a href="https://kaabworldwidetarot.shop/contact-us/" class = "hfe-menu-item">Contact Us</a></li>
</ul> 
				</nav>
			</div>
							</div>
				</div>
				</div>
				</div>
				</div>
					</div>
				</div>
				</div>
				</header>

	<main id="content" class="site-main">

			<div class="page-header">
			<h1 class="entry-title">The page can&rsquo;t be found.</h1>
		</div>
	
	<div class="page-content">
		<p>It looks like nothing was found at this location.</p>
	</div>

</main>

		<footer itemtype="https://schema.org/WPFooter" itemscope="itemscope" id="colophon" role="contentinfo">
			<div class='footer-width-fixer'>		<div data-elementor-type="wp-post" data-elementor-id="48" class="elementor elementor-48">
				<div class="elementor-element elementor-element-49788b0 e-flex e-con-boxed e-con e-parent" data-id="49788b0" data-element_type="container" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
					<div class="e-con-inner">
		<div class="elementor-element elementor-element-76d941e0 e-con-full e-flex e-con e-child" data-id="76d941e0" data-element_type="container">
		<div class="elementor-element elementor-element-4df91d6d e-con-full e-flex e-con e-child" data-id="4df91d6d" data-element_type="container">
				<div class="elementor-element elementor-element-5fc798a3 elementor-widget__width-initial elementor-widget elementor-widget-elementskit-heading" data-id="5fc798a3" data-element_type="widget" data-widget_type="elementskit-heading.default">
					<div class="ekit-wid-con" ><div class="ekit-heading elementskit-section-title-wraper text_left   ekit_heading_tablet-   ekit_heading_mobile-text_center"><h2 class="ekit-heading--title elementskit-section-title text_fill">let's <span>work</span> with <br><span>Next-Gen </span> Social Marketing</h2></div></div>				</div>
				</div>
		<div class="elementor-element elementor-element-497794be e-con-full e-flex e-con e-child" data-id="497794be" data-element_type="container">
				<div class="elementor-element elementor-element-7f59e754 elementor-view-stacked elementor-shape-circle elementor-widget elementor-widget-icon" data-id="7f59e754" data-element_type="widget" data-widget_type="icon.default">
							<div class="elementor-icon-wrapper">
			<a class="elementor-icon" href="https://kaabworldwidetarot.shop/contact-us/">
			<i aria-hidden="true" class="icon icon-right-arrow2"></i>			</a>
		</div>
						</div>
				</div>
				</div>
		<div class="elementor-element elementor-element-2d2c497a e-con-full e-flex e-con e-child" data-id="2d2c497a" data-element_type="container">
		<div class="elementor-element elementor-element-96b7cfc e-con-full e-flex e-con e-child" data-id="96b7cfc" data-element_type="container">
				<div class="elementor-element elementor-element-b4bfff2 elementor-widget elementor-widget-image" data-id="b4bfff2" data-element_type="widget" data-widget_type="image.default">
															<img width="250" height="122" src="https://kaabworldwidetarot.shop/wp-content/uploads/2025/08/ngs-1.webp" class="attachment-large size-large wp-image-1790" alt="" />															</div>
				<div class="elementor-element elementor-element-5bc75080 elementor-widget elementor-widget-text-editor" data-id="5bc75080" data-element_type="widget" data-widget_type="text-editor.default">
									<div class="elementor-element elementor-element-171318b5 e-con-full e-flex e-con e-child" data-id="171318b5" data-element_type="container"><div class="elementor-element elementor-element-3a1687a3 elementor-widget elementor-widget-text-editor" data-id="3a1687a3" data-element_type="widget" data-widget_type="text-editor.default"><p data-start="134" data-end="406">At Next-Gen Social Marketing, we are dedicated to helping businesses grow through innovative digital solutions.</p></div></div>								</div>
				<div class="elementor-element elementor-element-a4ab41f elementor-shape-circle e-grid-align-left e-grid-align-mobile-center elementor-grid-0 elementor-widget elementor-widget-social-icons" data-id="a4ab41f" data-element_type="widget" data-widget_type="social-icons.default">
							<div class="elementor-social-icons-wrapper elementor-grid" role="list">
							<span class="elementor-grid-item" role="listitem">
					<a class="elementor-icon elementor-social-icon elementor-social-icon-instagram elementor-repeater-item-45b57d8" href="https://www.instagram.com/nextgensocialmarketing__?igsh=MWJ5amRqNWc1M2Yxdw%3D%3D&#038;utm_source=qr" target="_blank">
						<span class="elementor-screen-only">Instagram</span>
						<svg aria-hidden="true" class="e-font-icon-svg e-fab-instagram" viewBox="0 0 448 512" xmlns="http://www.w3.org/2000/svg"><path d="M224.1 141c-63.6 0-114.9 51.3-114.9 114.9s51.3 114.9 114.9 114.9S339 319.5 339 255.9 287.7 141 224.1 141zm0 189.6c-41.1 0-74.7-33.5-74.7-74.7s33.5-74.7 74.7-74.7 74.7 33.5 74.7 74.7-33.6 74.7-74.7 74.7zm146.4-194.3c0 14.9-12 26.8-26.8 26.8-14.9 0-26.8-12-26.8-26.8s12-26.8 26.8-26.8 26.8 12 26.8 26.8zm76.1 27.2c-1.7-35.9-9.9-67.7-36.2-93.9-26.2-26.2-58-34.4-93.9-36.2-37-2.1-147.9-2.1-184.9 0-35.8 1.7-67.6 9.9-93.9 36.1s-34.4 58-36.2 93.9c-2.1 37-2.1 147.9 0 184.9 1.7 35.9 9.9 67.7 36.2 93.9s58 34.4 93.9 36.2c37 2.1 147.9 2.1 184.9 0 35.9-1.7 67.7-9.9 93.9-36.2 26.2-26.2 34.4-58 36.2-93.9 2.1-37 2.1-147.8 0-184.8zM398.8 388c-7.8 19.6-22.9 34.7-42.6 42.6-29.5 11.7-99.5 9-132.1 9s-102.7 2.6-132.1-9c-19.6-7.8-34.7-22.9-42.6-42.6-11.7-29.5-9-99.5-9-132.1s-2.6-102.7 9-132.1c7.8-19.6 22.9-34.7 42.6-42.6 29.5-11.7 99.5-9 132.1-9s102.7-2.6 132.1 9c19.6 7.8 34.7 22.9 42.6 42.6 11.7 29.5 9 99.5 9 132.1s2.7 102.7-9 132.1z"></path></svg>					</a>
				</span>
							<span class="elementor-grid-item" role="listitem">
					<a class="elementor-icon elementor-social-icon elementor-social-icon-facebook elementor-repeater-item-da61083" href="https://www.facebook.com/share/1as1g1Ksft/?mibextid=wwXIfr" target="_blank">
						<span class="elementor-screen-only">Facebook</span>
						<svg aria-hidden="true" class="e-font-icon-svg e-fab-facebook" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg"><path d="M504 256C504 119 393 8 256 8S8 119 8 256c0 123.78 90.69 226.38 209.25 245V327.69h-63V256h63v-54.64c0-62.15 37-96.48 93.67-96.48 27.14 0 55.52 4.84 55.52 4.84v61h-31.28c-30.8 0-40.41 19.12-40.41 38.73V256h68.78l-11 71.69h-57.78V501C413.31 482.38 504 379.78 504 256z"></path></svg>					</a>
				</span>
							<span class="elementor-grid-item" role="listitem">
					<a class="elementor-icon elementor-social-icon elementor-social-icon-whatsapp elementor-repeater-item-fb7fa80" href="https://wa.me/9165308690" target="_blank">
						<span class="elementor-screen-only">Whatsapp</span>
						<svg aria-hidden="true" class="e-font-icon-svg e-fab-whatsapp" viewBox="0 0 448 512" xmlns="http://www.w3.org/2000/svg"><path d="M380.9 97.1C339 55.1 283.2 32 223.9 32c-122.4 0-222 99.6-222 222 0 39.1 10.2 77.3 29.6 111L0 480l117.7-30.9c32.4 17.7 68.9 27 106.1 27h.1c122.3 0 224.1-99.6 224.1-222 0-59.3-25.2-115-67.1-157zm-157 341.6c-33.2 0-65.7-8.9-94-25.7l-6.7-4-69.8 18.3L72 359.2l-4.4-7c-18.5-29.4-28.2-63.3-28.2-98.2 0-101.7 82.8-184.5 184.6-184.5 49.3 0 95.6 19.2 130.4 54.1 34.8 34.9 56.2 81.2 56.1 130.5 0 101.8-84.9 184.6-186.6 184.6zm101.2-138.2c-5.5-2.8-32.8-16.2-37.9-18-5.1-1.9-8.8-2.8-12.5 2.8-3.7 5.6-14.3 18-17.6 21.8-3.2 3.7-6.5 4.2-12 1.4-32.6-16.3-54-29.1-75.5-66-5.7-9.8 5.7-9.1 16.3-30.3 1.8-3.7.9-6.9-.5-9.7-1.4-2.8-12.5-30.1-17.1-41.2-4.5-10.8-9.1-9.3-12.5-9.5-3.2-.2-6.9-.2-10.6-.2-3.7 0-9.7 1.4-14.8 6.9-5.1 5.6-19.4 19-19.4 46.3 0 27.3 19.9 53.7 22.6 57.4 2.8 3.7 39.1 59.7 94.8 83.8 35.2 15.2 49 16.5 66.6 13.9 10.7-1.6 32.8-13.4 37.4-26.4 4.6-13 4.6-24.1 3.2-26.4-1.3-2.5-5-3.9-10.5-6.6z"></path></svg>					</a>
				</span>
					</div>
						</div>
				</div>
		<div class="elementor-element elementor-element-2841444a e-con-full e-flex e-con e-child" data-id="2841444a" data-element_type="container">
		<div class="elementor-element elementor-element-56f4c86c e-con-full e-flex e-con e-child" data-id="56f4c86c" data-element_type="container">
				<div class="elementor-element elementor-element-76243c3e elementor-widget elementor-widget-heading" data-id="76243c3e" data-element_type="widget" data-widget_type="heading.default">
					<h6 class="elementor-heading-title elementor-size-default">our pages</h6>				</div>
				<div class="elementor-element elementor-element-344e7a91 elementor-mobile-align-center elementor-icon-list--layout-traditional elementor-list-item-link-full_width elementor-widget elementor-widget-icon-list" data-id="344e7a91" data-element_type="widget" data-widget_type="icon-list.default">
							<ul class="elementor-icon-list-items">
							<li class="elementor-icon-list-item">
											<a href="https://kaabworldwidetarot.shop/">

											<span class="elementor-icon-list-text">Home </span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="https://kaabworldwidetarot.shop/blogs/">

											<span class="elementor-icon-list-text">Blogs</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="https://kaabworldwidetarot.shop/about-us/">

											<span class="elementor-icon-list-text">About Us</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="https://kaabworldwidetarot.shop/contact-us/">

											<span class="elementor-icon-list-text">Contact Us</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="https://kaabworldwidetarot.shop/service/">

											<span class="elementor-icon-list-text">Our Services</span>
											</a>
									</li>
						</ul>
						</div>
				</div>
		<div class="elementor-element elementor-element-141c09b e-con-full e-flex e-con e-child" data-id="141c09b" data-element_type="container">
				<div class="elementor-element elementor-element-6031fbd1 elementor-widget elementor-widget-heading" data-id="6031fbd1" data-element_type="widget" data-widget_type="heading.default">
					<h6 class="elementor-heading-title elementor-size-default">get in touch</h6>				</div>
				<div class="elementor-element elementor-element-72c76aa5 elementor-mobile-align-center elementor-icon-list--layout-traditional elementor-list-item-link-full_width elementor-widget elementor-widget-icon-list" data-id="72c76aa5" data-element_type="widget" data-widget_type="icon-list.default">
							<ul class="elementor-icon-list-items">
							<li class="elementor-icon-list-item">
											<a href="tel:9165308690">

												<span class="elementor-icon-list-icon">
							<svg aria-hidden="true" class="e-font-icon-svg e-fas-phone-alt" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg"><path d="M497.39 361.8l-112-48a24 24 0 0 0-28 6.9l-49.6 60.6A370.66 370.66 0 0 1 130.6 204.11l60.6-49.6a23.94 23.94 0 0 0 6.9-28l-48-112A24.16 24.16 0 0 0 122.6.61l-104 24A24 24 0 0 0 0 48c0 256.5 207.9 464 464 464a24 24 0 0 0 23.4-18.6l24-104a24.29 24.29 0 0 0-14.01-27.6z"></path></svg>						</span>
										<span class="elementor-icon-list-text">+91 9165308690</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<span class="elementor-icon-list-icon">
							<svg aria-hidden="true" class="e-font-icon-svg e-fas-map-marker-alt" viewBox="0 0 384 512" xmlns="http://www.w3.org/2000/svg"><path d="M172.268 501.67C26.97 291.031 0 269.413 0 192 0 85.961 85.961 0 192 0s192 85.961 192 192c0 77.413-26.97 99.031-172.268 309.67-9.535 13.774-29.93 13.773-39.464 0zM192 272c44.183 0 80-35.817 80-80s-35.817-80-80-80-80 35.817-80 80 35.817 80 80 80z"></path></svg>						</span>
										<span class="elementor-icon-list-text">Vijay Nagar Postmaster, Post Office Vijay Nagar Indore District: Indore State: Madhya Pradesh PIN Code: 452010</span>
									</li>
						</ul>
						</div>
				</div>
				</div>
				</div>
					</div>
				</div>
		<div class="elementor-element elementor-element-6d97f2a9 e-flex e-con-boxed e-con e-parent" data-id="6d97f2a9" data-element_type="container" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
					<div class="e-con-inner">
		<div class="elementor-element elementor-element-320862f5 e-con-full e-flex e-con e-child" data-id="320862f5" data-element_type="container">
		<div class="elementor-element elementor-element-6f8a9693 e-con-full e-flex e-con e-child" data-id="6f8a9693" data-element_type="container">
				<div class="elementor-element elementor-element-fa3a90d elementor-widget elementor-widget-text-editor" data-id="fa3a90d" data-element_type="widget" data-widget_type="text-editor.default">
									© 2026 All Rights Reserved | Innovating 
<a href="https://kaabworldwidetarot.shop/" style="color:#ffffff;">Next-Gen Social Marketing</a> 
| Powered By 
<a href="https://kaabworldwideservices.com/" style="color:#ffffff;">Kaab Worldwide Services</a>
								</div>
				</div>
				</div>
					</div>
				</div>
		<div class="elementor-element elementor-element-976d109 e-con-full e-flex e-con e-parent" data-id="976d109" data-element_type="container">
				<div class="elementor-element elementor-element-1e2ff8b elementor-widget elementor-widget-html" data-id="1e2ff8b" data-element_type="widget" data-widget_type="html.default">
					<div class="nf-sticky-wrapper">
    <!-- Social Icons -->
    <ul class="nf-social-list">
        <li class="nf-social-item whatsapp">
            <a href="https://wa.me/9165308690" target="_blank">
                WhatsApp
            </a>
        </li>

        <li class="nf-social-item facebook">
            <a href="https://www.facebook.com/share/1as1g1Ksft/?mibextid=wwXIfr" target="_blank">
                Facebook
            </a>
        </li>

        <li class="nf-social-item instagram">
            <a href="https://www.instagram.com/nextgensocialmarketing__?igsh=MWJ5amRqNWc1M2Yxdw%3D%3D&utm_source=qr  " target="_blank">
                Instagram
            </a>
        </li>
<li class="nf-social-item youtube">
            <a href="https://youtube.com/@kaabworldwideservice?si=5hFhpYYTK5zKNq20" target="_blank">
                YouTube
            </a>
        </li>

        <li class="nf-social-item map">
            <a href="https://share.google/B1fHUSz2j5uOwrQj3" target="_blank">
                Location
            </a>
        </li>
    </ul>

</div>
				</div>
				</div>
		<div class="elementor-element elementor-element-30fc358 e-con-full e-flex e-con e-parent" data-id="30fc358" data-element_type="container">
				<div class="elementor-element elementor-element-62d446e elementor-widget elementor-widget-html" data-id="62d446e" data-element_type="widget" data-widget_type="html.default">
					<div class="callMePanel">
    <div class="iconMobPanel" id="callMe">
        <img src="https://kaabworldwideservices.in/wp-content/uploads/2026/01/enquiry-icon1.png" alt="Enquiry">
    </div>

    <div class="callMePanelBottom">
        <p class="formHead">Enquiry Form</p>
       
<div class="wpcf7 no-js" id="wpcf7-f1813-o1" lang="en-US" dir="ltr" data-wpcf7-id="1813">
<div class="screen-reader-response"><p role="status" aria-live="polite" aria-atomic="true"></p> <ul></ul></div>
<form action="/cute-alert.js#wpcf7-f1813-o1" method="post" class="wpcf7-form init" aria-label="Contact form" novalidate="novalidate" data-status="init">
<fieldset class="hidden-fields-container"><input type="hidden" name="_wpcf7" value="1813" /><input type="hidden" name="_wpcf7_version" value="6.1.4" /><input type="hidden" name="_wpcf7_locale" value="en_US" /><input type="hidden" name="_wpcf7_unit_tag" value="wpcf7-f1813-o1" /><input type="hidden" name="_wpcf7_container_post" value="0" /><input type="hidden" name="_wpcf7_posted_data_hash" value="" />
</fieldset>
<label> Your name
    <span class="wpcf7-form-control-wrap" data-name="your-name"><input size="40" maxlength="400" class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required" autocomplete="name" aria-required="true" aria-invalid="false" value="" type="text" name="your-name" /></span> </label>

<label> Your email
    <span class="wpcf7-form-control-wrap" data-name="your-email"><input size="40" maxlength="400" class="wpcf7-form-control wpcf7-email wpcf7-validates-as-required wpcf7-text wpcf7-validates-as-email" autocomplete="email" aria-required="true" aria-invalid="false" value="" type="email" name="your-email" /></span> </label>

<label> Subject
    <span class="wpcf7-form-control-wrap" data-name="your-subject"><input size="40" maxlength="400" class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required" aria-required="true" aria-invalid="false" value="" type="text" name="your-subject" /></span> </label>

<label> Your message (optional)
    <span class="wpcf7-form-control-wrap" data-name="your-message"><textarea cols="40" rows="10" maxlength="2000" class="wpcf7-form-control wpcf7-textarea" aria-invalid="false" name="your-message"></textarea></span> </label>

<input class="wpcf7-form-control wpcf7-submit has-spinner" type="submit" value="Submit" /><div class="wpcf7-response-output" aria-hidden="true"></div>
</form>
</div>

    </div>
</div>
				</div>
				</div>
				</div>
		</div>		</footer>
	</div><!-- #page -->
<script type="speculationrules">
{"prefetch":[{"source":"document","where":{"and":[{"href_matches":"\/*"},{"not":{"href_matches":["\/wp-*.php","\/wp-admin\/*","\/wp-content\/uploads\/*","\/wp-content\/*","\/wp-content\/plugins\/*","\/wp-content\/themes\/hello-elementor\/*","\/*\\?(.+)"]}},{"not":{"selector_matches":"a[rel~=\"nofollow\"]"}},{"not":{"selector_matches":".no-prefetch, .no-prefetch a"}}]},"eagerness":"conservative"}]}
</script>
			<script>
				const lazyloadRunObserver = () => {
					const lazyloadBackgrounds = document.querySelectorAll( `.e-con.e-parent:not(.e-lazyloaded)` );
					const lazyloadBackgroundObserver = new IntersectionObserver( ( entries ) => {
						entries.forEach( ( entry ) => {
							if ( entry.isIntersecting ) {
								let lazyloadBackground = entry.target;
								if( lazyloadBackground ) {
									lazyloadBackground.classList.add( 'e-lazyloaded' );
								}
								lazyloadBackgroundObserver.unobserve( entry.target );
							}
						});
					}, { rootMargin: '200px 0px 200px 0px' } );
					lazyloadBackgrounds.forEach( ( lazyloadBackground ) => {
						lazyloadBackgroundObserver.observe( lazyloadBackground );
					} );
				};
				const events = [
					'DOMContentLoaded',
					'elementor/lazyload/observe',
				];
				events.forEach( ( event ) => {
					document.addEventListener( event, lazyloadRunObserver );
				} );
			</script>
			<link rel='stylesheet' id='font-awesome-5-all-css' href='https://kaabworldwidetarot.shop/wp-content/plugins/elementor/assets/lib/font-awesome/css/all.min.css?ver=3.33.4' media='all' />
<link rel='stylesheet' id='font-awesome-4-shim-css' href='https://kaabworldwidetarot.shop/wp-content/plugins/elementor/assets/lib/font-awesome/css/v4-shims.min.css?ver=3.33.4' media='all' />
<link rel='stylesheet' id='widget-social-icons-css' href='https://kaabworldwidetarot.shop/wp-content/plugins/elementor/assets/css/widget-social-icons.min.css?ver=3.33.4' media='all' />
<link rel='stylesheet' id='e-apple-webkit-css' href='https://kaabworldwidetarot.shop/wp-content/plugins/elementor/assets/css/conditionals/apple-webkit.min.css?ver=3.33.4' media='all' />
<style id='global-styles-inline-css'>
:root{--wp--preset--aspect-ratio--square: 1;--wp--preset--aspect-ratio--4-3: 4/3;--wp--preset--aspect-ratio--3-4: 3/4;--wp--preset--aspect-ratio--3-2: 3/2;--wp--preset--aspect-ratio--2-3: 2/3;--wp--preset--aspect-ratio--16-9: 16/9;--wp--preset--aspect-ratio--9-16: 9/16;--wp--preset--color--black: #000000;--wp--preset--color--cyan-bluish-gray: #abb8c3;--wp--preset--color--white: #ffffff;--wp--preset--color--pale-pink: #f78da7;--wp--preset--color--vivid-red: #cf2e2e;--wp--preset--color--luminous-vivid-orange: #ff6900;--wp--preset--color--luminous-vivid-amber: #fcb900;--wp--preset--color--light-green-cyan: #7bdcb5;--wp--preset--color--vivid-green-cyan: #00d084;--wp--preset--color--pale-cyan-blue: #8ed1fc;--wp--preset--color--vivid-cyan-blue: #0693e3;--wp--preset--color--vivid-purple: #9b51e0;--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple: linear-gradient(135deg,rgba(6,147,227,1) 0%,rgb(155,81,224) 100%);--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan: linear-gradient(135deg,rgb(122,220,180) 0%,rgb(0,208,130) 100%);--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange: linear-gradient(135deg,rgba(252,185,0,1) 0%,rgba(255,105,0,1) 100%);--wp--preset--gradient--luminous-vivid-orange-to-vivid-red: linear-gradient(135deg,rgba(255,105,0,1) 0%,rgb(207,46,46) 100%);--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray: linear-gradient(135deg,rgb(238,238,238) 0%,rgb(169,184,195) 100%);--wp--preset--gradient--cool-to-warm-spectrum: linear-gradient(135deg,rgb(74,234,220) 0%,rgb(151,120,209) 20%,rgb(207,42,186) 40%,rgb(238,44,130) 60%,rgb(251,105,98) 80%,rgb(254,248,76) 100%);--wp--preset--gradient--blush-light-purple: linear-gradient(135deg,rgb(255,206,236) 0%,rgb(152,150,240) 100%);--wp--preset--gradient--blush-bordeaux: linear-gradient(135deg,rgb(254,205,165) 0%,rgb(254,45,45) 50%,rgb(107,0,62) 100%);--wp--preset--gradient--luminous-dusk: linear-gradient(135deg,rgb(255,203,112) 0%,rgb(199,81,192) 50%,rgb(65,88,208) 100%);--wp--preset--gradient--pale-ocean: linear-gradient(135deg,rgb(255,245,203) 0%,rgb(182,227,212) 50%,rgb(51,167,181) 100%);--wp--preset--gradient--electric-grass: linear-gradient(135deg,rgb(202,248,128) 0%,rgb(113,206,126) 100%);--wp--preset--gradient--midnight: linear-gradient(135deg,rgb(2,3,129) 0%,rgb(40,116,252) 100%);--wp--preset--font-size--small: 13px;--wp--preset--font-size--medium: 20px;--wp--preset--font-size--large: 36px;--wp--preset--font-size--x-large: 42px;--wp--preset--spacing--20: 0.44rem;--wp--preset--spacing--30: 0.67rem;--wp--preset--spacing--40: 1rem;--wp--preset--spacing--50: 1.5rem;--wp--preset--spacing--60: 2.25rem;--wp--preset--spacing--70: 3.38rem;--wp--preset--spacing--80: 5.06rem;--wp--preset--shadow--natural: 6px 6px 9px rgba(0, 0, 0, 0.2);--wp--preset--shadow--deep: 12px 12px 50px rgba(0, 0, 0, 0.4);--wp--preset--shadow--sharp: 6px 6px 0px rgba(0, 0, 0, 0.2);--wp--preset--shadow--outlined: 6px 6px 0px -3px rgba(255, 255, 255, 1), 6px 6px rgba(0, 0, 0, 1);--wp--preset--shadow--crisp: 6px 6px 0px rgba(0, 0, 0, 1);}:root { --wp--style--global--content-size: 800px;--wp--style--global--wide-size: 1200px; }:where(body) { margin: 0; }.wp-site-blocks > .alignleft { float: left; margin-right: 2em; }.wp-site-blocks > .alignright { float: right; margin-left: 2em; }.wp-site-blocks > .aligncenter { justify-content: center; margin-left: auto; margin-right: auto; }:where(.wp-site-blocks) > * { margin-block-start: 24px; margin-block-end: 0; }:where(.wp-site-blocks) > :first-child { margin-block-start: 0; }:where(.wp-site-blocks) > :last-child { margin-block-end: 0; }:root { --wp--style--block-gap: 24px; }:root :where(.is-layout-flow) > :first-child{margin-block-start: 0;}:root :where(.is-layout-flow) > :last-child{margin-block-end: 0;}:root :where(.is-layout-flow) > *{margin-block-start: 24px;margin-block-end: 0;}:root :where(.is-layout-constrained) > :first-child{margin-block-start: 0;}:root :where(.is-layout-constrained) > :last-child{margin-block-end: 0;}:root :where(.is-layout-constrained) > *{margin-block-start: 24px;margin-block-end: 0;}:root :where(.is-layout-flex){gap: 24px;}:root :where(.is-layout-grid){gap: 24px;}.is-layout-flow > .alignleft{float: left;margin-inline-start: 0;margin-inline-end: 2em;}.is-layout-flow > .alignright{float: right;margin-inline-start: 2em;margin-inline-end: 0;}.is-layout-flow > .aligncenter{margin-left: auto !important;margin-right: auto !important;}.is-layout-constrained > .alignleft{float: left;margin-inline-start: 0;margin-inline-end: 2em;}.is-layout-constrained > .alignright{float: right;margin-inline-start: 2em;margin-inline-end: 0;}.is-layout-constrained > .aligncenter{margin-left: auto !important;margin-right: auto !important;}.is-layout-constrained > :where(:not(.alignleft):not(.alignright):not(.alignfull)){max-width: var(--wp--style--global--content-size);margin-left: auto !important;margin-right: auto !important;}.is-layout-constrained > .alignwide{max-width: var(--wp--style--global--wide-size);}body .is-layout-flex{display: flex;}.is-layout-flex{flex-wrap: wrap;align-items: center;}.is-layout-flex > :is(*, div){margin: 0;}body .is-layout-grid{display: grid;}.is-layout-grid > :is(*, div){margin: 0;}body{padding-top: 0px;padding-right: 0px;padding-bottom: 0px;padding-left: 0px;}a:where(:not(.wp-element-button)){text-decoration: underline;}:root :where(.wp-element-button, .wp-block-button__link){background-color: #32373c;border-width: 0;color: #fff;font-family: inherit;font-size: inherit;line-height: inherit;padding: calc(0.667em + 2px) calc(1.333em + 2px);text-decoration: none;}.has-black-color{color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-color{color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-color{color: var(--wp--preset--color--white) !important;}.has-pale-pink-color{color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-color{color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-color{color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-color{color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-color{color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-color{color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-color{color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-color{color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-color{color: var(--wp--preset--color--vivid-purple) !important;}.has-black-background-color{background-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-background-color{background-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-background-color{background-color: var(--wp--preset--color--white) !important;}.has-pale-pink-background-color{background-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-background-color{background-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-background-color{background-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-background-color{background-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-background-color{background-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-background-color{background-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-background-color{background-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-background-color{background-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-background-color{background-color: var(--wp--preset--color--vivid-purple) !important;}.has-black-border-color{border-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-border-color{border-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-border-color{border-color: var(--wp--preset--color--white) !important;}.has-pale-pink-border-color{border-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-border-color{border-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-border-color{border-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-border-color{border-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-border-color{border-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-border-color{border-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-border-color{border-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-border-color{border-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-border-color{border-color: var(--wp--preset--color--vivid-purple) !important;}.has-vivid-cyan-blue-to-vivid-purple-gradient-background{background: var(--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple) !important;}.has-light-green-cyan-to-vivid-green-cyan-gradient-background{background: var(--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan) !important;}.has-luminous-vivid-amber-to-luminous-vivid-orange-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange) !important;}.has-luminous-vivid-orange-to-vivid-red-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-orange-to-vivid-red) !important;}.has-very-light-gray-to-cyan-bluish-gray-gradient-background{background: var(--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray) !important;}.has-cool-to-warm-spectrum-gradient-background{background: var(--wp--preset--gradient--cool-to-warm-spectrum) !important;}.has-blush-light-purple-gradient-background{background: var(--wp--preset--gradient--blush-light-purple) !important;}.has-blush-bordeaux-gradient-background{background: var(--wp--preset--gradient--blush-bordeaux) !important;}.has-luminous-dusk-gradient-background{background: var(--wp--preset--gradient--luminous-dusk) !important;}.has-pale-ocean-gradient-background{background: var(--wp--preset--gradient--pale-ocean) !important;}.has-electric-grass-gradient-background{background: var(--wp--preset--gradient--electric-grass) !important;}.has-midnight-gradient-background{background: var(--wp--preset--gradient--midnight) !important;}.has-small-font-size{font-size: var(--wp--preset--font-size--small) !important;}.has-medium-font-size{font-size: var(--wp--preset--font-size--medium) !important;}.has-large-font-size{font-size: var(--wp--preset--font-size--large) !important;}.has-x-large-font-size{font-size: var(--wp--preset--font-size--x-large) !important;}
</style>
<script src="https://kaabworldwidetarot.shop/wp-includes/js/dist/hooks.min.js?ver=4d63a3d491d11ffd8ac6" id="wp-hooks-js"></script>
<script src="https://kaabworldwidetarot.shop/wp-includes/js/dist/i18n.min.js?ver=5e580eb46a90c2b997e6" id="wp-i18n-js"></script>
<script id="wp-i18n-js-after">
wp.i18n.setLocaleData( { 'text direction\u0004ltr': [ 'ltr' ] } );
</script>
<script src="https://kaabworldwidetarot.shop/wp-content/plugins/contact-form-7/includes/swv/js/index.js?ver=6.1.4" id="swv-js"></script>
<script id="contact-form-7-js-before">
var wpcf7 = {
    "api": {
        "root": "https:\/\/kaabworldwidetarot.shop\/wp-json\/",
        "namespace": "contact-form-7\/v1"
    }
};
</script>
<script src="https://kaabworldwidetarot.shop/wp-content/plugins/contact-form-7/includes/js/index.js?ver=6.1.4" id="contact-form-7-js"></script>
<script src="https://kaabworldwidetarot.shop/wp-includes/js/jquery/ui/core.min.js?ver=1.13.3" id="jquery-ui-core-js"></script>
<script id="qi-addons-for-elementor-script-js-extra">
var qodefQiAddonsGlobal = {"vars":{"adminBarHeight":0,"iconArrowLeft":"<svg  xmlns=\"http:\/\/www.w3.org\/2000\/svg\" x=\"0px\" y=\"0px\" viewBox=\"0 0 34.2 32.3\" xml:space=\"preserve\" style=\"stroke-width: 2;\"><line x1=\"0.5\" y1=\"16\" x2=\"33.5\" y2=\"16\"\/><line x1=\"0.3\" y1=\"16.5\" x2=\"16.2\" y2=\"0.7\"\/><line x1=\"0\" y1=\"15.4\" x2=\"16.2\" y2=\"31.6\"\/><\/svg>","iconArrowRight":"<svg  xmlns=\"http:\/\/www.w3.org\/2000\/svg\" x=\"0px\" y=\"0px\" viewBox=\"0 0 34.2 32.3\" xml:space=\"preserve\" style=\"stroke-width: 2;\"><line x1=\"0\" y1=\"16\" x2=\"33\" y2=\"16\"\/><line x1=\"17.3\" y1=\"0.7\" x2=\"33.2\" y2=\"16.5\"\/><line x1=\"17.3\" y1=\"31.6\" x2=\"33.5\" y2=\"15.4\"\/><\/svg>","iconClose":"<svg  xmlns=\"http:\/\/www.w3.org\/2000\/svg\" x=\"0px\" y=\"0px\" viewBox=\"0 0 9.1 9.1\" xml:space=\"preserve\"><g><path d=\"M8.5,0L9,0.6L5.1,4.5L9,8.5L8.5,9L4.5,5.1L0.6,9L0,8.5L4,4.5L0,0.6L0.6,0L4.5,4L8.5,0z\"\/><\/g><\/svg>"}};
</script>
<script src="https://kaabworldwidetarot.shop/wp-content/plugins/qi-addons-for-elementor/assets/js/main.min.js?ver=1.9.3" id="qi-addons-for-elementor-script-js"></script>
<script src="https://kaabworldwidetarot.shop/wp-content/plugins/metform/public/assets/lib/cute-alert/cute-alert.js?ver=4.0.5" id="cute-alert-js"></script>
<script src="https://kaabworldwidetarot.shop/wp-content/themes/hello-elementor/assets/js/hello-frontend.js?ver=3.4.4" id="hello-theme-frontend-js"></script>
<script src="https://kaabworldwidetarot.shop/wp-content/plugins/elementskit-lite/libs/framework/assets/js/frontend-script.js?ver=3.6.1" id="elementskit-framework-js-frontend-js"></script>
<script id="elementskit-framework-js-frontend-js-after">
		var elementskit = {
			resturl: 'https://kaabworldwidetarot.shop/wp-json/elementskit/v1/',
		}

		
</script>
<script src="https://kaabworldwidetarot.shop/wp-content/plugins/elementskit-lite/widgets/init/assets/js/widget-scripts.js?ver=3.6.1" id="ekit-widget-scripts-js"></script>
<script src="https://kaabworldwidetarot.shop/wp-content/plugins/header-footer-elementor/inc/js/frontend.js?ver=2.5.2" id="hfe-frontend-js-js"></script>
<script src="https://kaabworldwidetarot.shop/wp-content/plugins/elementor/assets/lib/font-awesome/js/v4-shims.min.js?ver=3.33.4" id="font-awesome-4-shim-js"></script>
<script src="https://kaabworldwidetarot.shop/wp-content/plugins/elementor/assets/js/webpack.runtime.min.js?ver=3.33.4" id="elementor-webpack-runtime-js"></script>
<script src="https://kaabworldwidetarot.shop/wp-content/plugins/elementor/assets/js/frontend-modules.min.js?ver=3.33.4" id="elementor-frontend-modules-js"></script>
<script id="elementor-frontend-js-before">
var elementorFrontendConfig = {"environmentMode":{"edit":false,"wpPreview":false,"isScriptDebug":false},"i18n":{"shareOnFacebook":"Share on Facebook","shareOnTwitter":"Share on Twitter","pinIt":"Pin it","download":"Download","downloadImage":"Download image","fullscreen":"Fullscreen","zoom":"Zoom","share":"Share","playVideo":"Play Video","previous":"Previous","next":"Next","close":"Close","a11yCarouselPrevSlideMessage":"Previous slide","a11yCarouselNextSlideMessage":"Next slide","a11yCarouselFirstSlideMessage":"This is the first slide","a11yCarouselLastSlideMessage":"This is the last slide","a11yCarouselPaginationBulletMessage":"Go to slide"},"is_rtl":false,"breakpoints":{"xs":0,"sm":480,"md":768,"lg":1025,"xl":1440,"xxl":1600},"responsive":{"breakpoints":{"mobile":{"label":"Mobile Portrait","value":767,"default_value":767,"direction":"max","is_enabled":true},"mobile_extra":{"label":"Mobile Landscape","value":880,"default_value":880,"direction":"max","is_enabled":false},"tablet":{"label":"Tablet Portrait","value":1024,"default_value":1024,"direction":"max","is_enabled":true},"tablet_extra":{"label":"Tablet Landscape","value":1200,"default_value":1200,"direction":"max","is_enabled":false},"laptop":{"label":"Laptop","value":1366,"default_value":1366,"direction":"max","is_enabled":false},"widescreen":{"label":"Widescreen","value":2400,"default_value":2400,"direction":"min","is_enabled":false}},"hasCustomBreakpoints":false},"version":"3.33.4","is_static":false,"experimentalFeatures":{"e_font_icon_svg":true,"additional_custom_breakpoints":true,"container":true,"e_optimized_markup":true,"hello-theme-header-footer":true,"nested-elements":true,"home_screen":true,"global_classes_should_enforce_capabilities":true,"e_variables":true,"cloud-library":true,"e_opt_in_v4_page":true,"import-export-customization":true},"urls":{"assets":"https:\/\/kaabworldwidetarot.shop\/wp-content\/plugins\/elementor\/assets\/","ajaxurl":"https:\/\/kaabworldwidetarot.shop\/wp-admin\/admin-ajax.php","uploadUrl":"http:\/\/kaabworldwidetarot.shop\/wp-content\/uploads"},"nonces":{"floatingButtonsClickTracking":"e8ec19d4f5"},"swiperClass":"swiper","settings":{"editorPreferences":[]},"kit":{"body_background_background":"classic","active_breakpoints":["viewport_mobile","viewport_tablet"],"global_image_lightbox":"yes","lightbox_enable_counter":"yes","lightbox_enable_fullscreen":"yes","lightbox_enable_zoom":"yes","lightbox_enable_share":"yes","lightbox_title_src":"title","lightbox_description_src":"description","hello_header_logo_type":"title","hello_header_menu_layout":"horizontal","hello_footer_logo_type":"logo"},"post":{"id":0,"title":"Page not found - kaabworldwidemarkating.online","excerpt":""}};
</script>
<script src="https://kaabworldwidetarot.shop/wp-content/plugins/elementor/assets/js/frontend.min.js?ver=3.33.4" id="elementor-frontend-js"></script>
<script src="https://kaabworldwidetarot.shop/wp-content/plugins/qi-addons-for-elementor/inc/plugins/elementor/assets/js/elementor.js?ver=6.8.3" id="qi-addons-for-elementor-elementor-js"></script>
<script src="https://kaabworldwidetarot.shop/wp-content/plugins/elementskit-lite/widgets/init/assets/js/animate-circle.min.js?ver=3.6.1" id="animate-circle-js"></script>
<script id="elementskit-elementor-js-extra">
var ekit_config = {"ajaxurl":"https:\/\/kaabworldwidetarot.shop\/wp-admin\/admin-ajax.php","nonce":"1ab438a0fc"};
</script>
<script src="https://kaabworldwidetarot.shop/wp-content/plugins/elementskit-lite/widgets/init/assets/js/elementor.js?ver=3.6.1" id="elementskit-elementor-js"></script>
</body>
</html> 
